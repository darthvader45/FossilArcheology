package mods.fossil.fossilEnums;

public enum EnumSituation
{
    Hungry,
    Starve,
    LearningChest,
    Betrayed,
    NoSpace,
    StarveEsc,
    SJLBite,
    ChewTime,
    Full,
    Nervous,
    GemErrorYoung,
    GemErrorHealth;
}