package mods.fossil.fossilEnums;

public enum EnumPigBossSpeaks
{
    Hello,
    BareHand,
    Draw,
    Coward,
    LeartHere,
    LeartThere,
    UnknownRanged,
    UnknownMelee,
    summon,
    Trans,
    Qi,
    FireRain;
}
