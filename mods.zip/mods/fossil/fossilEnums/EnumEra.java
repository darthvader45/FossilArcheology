package mods.fossil.fossilEnums;

public enum EnumEra {
	Now,
	StoneAge,
	Cretaceous,
	Jurassic,
	Triassic;
}
