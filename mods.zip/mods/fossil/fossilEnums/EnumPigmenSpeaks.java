package mods.fossil.fossilEnums;

public enum EnumPigmenSpeaks
{
    SelfKill,
    LifeFor,
    AnuSommon;
}
