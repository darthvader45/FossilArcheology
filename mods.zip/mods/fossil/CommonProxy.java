package mods.fossil;

public class CommonProxy 
{

	public void registerRenderThings() 
	{
		
	}
	
	public void registerTileEntitySpecialRenderer() {}
	
	public void registerSounds()
	{
	
	}
	
}
