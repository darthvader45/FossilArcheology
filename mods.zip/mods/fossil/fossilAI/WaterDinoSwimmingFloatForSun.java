package mods.fossil.fossilAI;

import mods.fossil.entity.mob.EntityDinosaur;


public class WaterDinoSwimmingFloatForSun extends WaterDinoAISwimming
{
    public WaterDinoSwimmingFloatForSun(EntityDinosaur var1, boolean var2, float var3)
    {
        super(var1, var2, var3);
    }

    /**
     * Updates the task
     */
    public void updateTask() {}
}
