package mods.fossil.guiBlocks;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;

public class ContainerPedia extends Container
{
    public boolean canInteractWith(EntityPlayer var1)
    {
        return true;
    }
}
