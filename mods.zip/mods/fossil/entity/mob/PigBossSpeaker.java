package mods.fossil.entity.mob;

import mods.fossil.fossilEnums.EnumPigBossSpeaks;


public class PigBossSpeaker
{
    public void SendSpeech(EnumPigBossSpeaks var1) {}
}
